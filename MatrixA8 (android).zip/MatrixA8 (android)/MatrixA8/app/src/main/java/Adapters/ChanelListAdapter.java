package Adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import Datas.DStatic;
import cn.com.williamxia.matrixa8.R;

/**
 * Created by williamXia on 2017/11/23.
 */

public class ChanelListAdapter extends BaseAdapter {

    private Context mContext;
    private int mSelectindex;
    //


    public ChanelListAdapter(Context mContext) {
        this.mContext = mContext;
    }

    public Context getmContext() {
        return mContext;
    }

    public void setmContext(Context mContext) {
        this.mContext = mContext;

    }

    public int getmSelectindex() {
        return mSelectindex;
    }

    public void setmSelectindex(int mSelectindex) {
        this.mSelectindex = mSelectindex;
        this.notifyDataSetInvalidated();
    }

    @Override
    public int getCount() {
        return DStatic.StrChanelList.length;
    }

    @Override
    public Object getItem(int i) {
        return DStatic.StrChanelList[i];
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        ViewHolder holder=null;
        if(view==null)
        {
            view= LayoutInflater.from(mContext).inflate(R.layout.chanel_list_item,null);
            holder=new ViewHolder();
            //
            holder.item=(TextView)view.findViewById(R.id.list_selectItem);
            view.setTag(holder);
            //
        }
        else
        {
            holder=(ViewHolder)view.getTag();
        }
        if(mSelectindex==i)
            holder.item.setBackgroundColor(mContext.getResources().getColor(R.color.orangered));
        else
        {
            holder.item.setBackgroundColor(mContext.getResources().getColor(R.color.bg_color));

        }
        holder.item.setText(DStatic.StrChanelList[i]);
        return view;
    }

    public class ViewHolder{
        TextView item;

    }


}
