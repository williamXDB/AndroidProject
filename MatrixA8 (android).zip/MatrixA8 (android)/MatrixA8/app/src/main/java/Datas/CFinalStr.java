package Datas;

/**
 * Created by williamXia on 2017/12/1.
 */

public class CFinalStr {
    public final static String No_NetWork="No network connection";
    public final static String No_ItemChoose="You should choose a item first.";

}
