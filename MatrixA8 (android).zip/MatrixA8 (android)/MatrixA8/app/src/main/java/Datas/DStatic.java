package Datas;

import android.os.Environment;

/**
 * Created by williamXia on 2017/9/6.
 */

public class DStatic {


    public static final String SD_Path_SaveLoad = Environment.getExternalStorageDirectory().getAbsolutePath() + "/MatrixA8/presets";

    public static final String[] StrChanelList = {
            "CH01", "CH02", "CH03", "CH04", "CH05", "CH06", "CH07", "CH08", "CH09",
            "CH10", "CH11", "CH12",
    };
    public static final int HeartTimeDelay=3000;

    public static final int CPageUPdate = 500;
    public static final String MemPresetsName = "MatrixA8Memory"; //filename for memory save/read

    public static final String StrPresetHeader = "MatrixA8 Presets File";
    public static final String StrMemoryHeader = "MatrixA8 AllMemory File";

    public static final int PKLen_ACK = 13;
    public static final int CEQ_MAX = 10;

    public static final int ChanlMax = 12;
    public static final int Matrix_CHNum = 32;
    public static final int IO_MaxMatrixBus = 24;
    public static final int Max_FBCFilter = 24;
    public static final int Max_DuckerParams = 6;
    //
    public static final int FBC_FFTNum = 24;


    public static final int AP_ALP50 = 22;
    public static final int AP_CLV = 4;
    public static final int AP_DCS_100 = 16;
    public static final int AP_DLM_A8 = 2;
    //--------
    public static final int AP_MA8 = 6;
    public static final int AP_D8 = 7;
    public static final int AP_RIO = 11;
    public static final int AP_Router = 20;
    //
    public static final int AP_RPM = 8;
    public static final int AP_RVA = 10;
    public static final int AP_RVC = 9;

    public static final int MIN_Len_Pack = 13;


    public static final int Len_FirmwareTrans = 1024 + 15;


    public static final int MIN_LEN_PACK = 18;
    public static final int LEN_CopyPack = 27;

    public static final int LEN_ACKPack = 13;
    //
    public static final int LEN_changeDevNamePack = 33;

    public static final int LEN_ComPack = 25;
    public static final int LEN_RecallSinglePresetPack = 14;//
    //
    public static final int LEN_DeletePack = 14;

    public static final int Memory_Per_Packeg_len = 4115;
    public static final int LEN_StoreNamePresetPack = 30;//
    public static final int Memory_Max_Package = 25;

    //
    public static final int LEN_Sence = 3649;
    public static final int LEN_MatrixPack = 30;
    public static final int LEN_DelPresetPack = 14;

    //---

    public static final String Ver_MCU = " Loading firmware MCU sucessfully, v1.1";
    public static final String Ver_Dsp = " Loading firmware DSP sucessfully,  v1.1";
    public static final String Ver_Mcu1763 = " Loading firmware MCUII  sucessfully,   v1.1";
    //------------------------
    public static final String Ver_Rpm = " Loading firmware RPM200 sucessfully,  v1.1";
    public static final String Ver_RIO = " Loading firmware RIO200  sucessfully, v1.1";
    public static final String Ver_Rva = " Loading firmware RVA200  sucessfully, v1.1";
    public static final String Ver_Rvc = " Loading firmware RVC200  sucessfully, v1.1";

    public static final String[] M_verAry = {
            Ver_MCU, Ver_Dsp, Ver_Mcu1763, Ver_Rpm, Ver_RIO, Ver_Rva, Ver_Rvc

    };


    public static final int CMD_CHECK_DEVICE = 0xAA;

    public static final int CMD_MCU_IAP_Enter_IN_App = 0xEE; //enter the iap mode for firmware begin..
    public static final int CMD_MCU_READY_PROGRAM = 0xEF;
    public static final int CMD_MCU_DO_PROGRAM = 0xF0;
    public static final int CMD_MCU_FINISH_PROGRAM = 0xF1;

    //dsp firmware update
    public static final int CMD_DSP_EnterUpdateBegin = 0xF2;
    public static final int CMD_DSP_DO_PROGRAM = 0xF3;
    public static final int CMD_DSP_Finish_PROGRAM = 0xF5;  //test
    public static final int SCAN_ALL_APID = 0xFFFF;


    //read DSP below
    public static final int CMD_Read_DSPCode = 0xF4;

    public static final int MAX_DSP_Package = 322;
    //
    public static final int CMD_READY_STOP = 0xE0;
    public static final int CMD_GETADDRS_RECALL = 0X21;


    public static final int Len_DevName = 16;

    public static final String RebootString = "Equipment is rebooting,please wait... %d";

    public static final byte BZero = 0;
    public static final byte BOne = 1;

    public static final int LEN_Preset_Dsp = 779;
    public static final int LEN_Preset_GEQ = 779;
    public static final int LEN_Preset_Dfx = 1675;
    public static final int LEN_Preset_Scen = 395;


    public static final int PKLen_ReadDevInf = 13;


    public static final int MODE_FATDSP = 1, MODE_GEQ = 2, MODE_DFX = 3, MODE_SCENE = 4, MODE_CURRENT_SCENE = 5;


    public static final int LEN_FILE_PRESET[] = {
            70, 44, 25, 4569
    };

    public static final int DSP_LEN = 269;//for read dsp data from device

    public static final int EpromSeneLength = 4612;
    public static final int EpromFatDSPLength = 2892;
    public static final int EpromDfxLength = 2300;
    public static final int EpromGEQLength = 3276;

    public static final int CountDownDelay = 20 * 1000;
    public static final int CountDownInteval = 1000;

    //--------
    //region--for braadcast
    public static final String Action_MainActivity = "Action.MatrixA8_mainActivity";
    public static final String Msg_Key_MainActivity = "Key_MainActivity_Do";
    public static final String Msg_ID_BeginConnect = "ID_MainActivity_BeginConnect";

    public static final int MConnect=1938;
    public static final int MDisconnect=1939;

    //
    public static final String Action_DspChanelFrag = "Action.MatrixA8_dspFrag";
    public static final String Msg_Key_DspChanel = "Key_DspChanelFrag";
    public static final String Msg_ID_DspChanel = "ID_DspChanelFrag";


    public static final String Action_IPConfigFrag = "Action.MatrixA8_IpConfigFrag";
    public static final String Msg_Key_IpConfig = "Key_IpConfigFrag";
    public static final String Msg_ID_IPConfig = "ID_IpConfigFrag";

    //
    public static final String Action_MatrixFrag = "Action.MatrixFrag";
    public static final String Msg_Key_Matrix = "Key_MatrixFrag";
    public static final String Msg_ID_Matrix = "ID_MatrixFrag";

    //
    public static final String Action_Preset = "Action.PresetFrag";
    public static final String Msg_Key_Preset = "Key_PresetFrag";
    public static final String Msg_ID_Preset = "ID_PresetFrag";

    //--------
    //endregion


    public static final String FM_MCU = "DMMB20160905";
    public static final String FM_DSP = "DMDB20160905";//
    public static final String FM_MA8_1763 = "EMMB20160905";// for matrix A8 only

    public static final String FM_RIO = "RIOB20160905";
    public static final String FM_RPM = "RPMB20160905";
    public static final String FM_RVA = "RVAB20160905";//
    public static final String FM_RVC = "RVCB20160905";


    public static final int e_mcu = 0, e_dsp = 1, e_ma8_1763 = 2, e_rpm = 3, e_rio = 4, e_rva = 5, e_rvc = 6;

    public static final String[] m_Firmwares = {

            FM_MCU, FM_DSP, FM_MA8_1763, FM_RPM, FM_RIO, FM_RVA, FM_RVC
    };


}
