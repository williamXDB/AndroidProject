package WinPages;


import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.PopupWindow;
import android.widget.TextView;

import java.text.DecimalFormat;

import Datas.Command;
import Datas.DStatic;
import Datas.XData;
import cn.com.williamxia.matrixa8.R;
import cn.com.williamxia.wipack.control.CSlider;
import cn.com.williamxia.wipack.socket.TCPClient;
import cn.com.williamxia.wipack.utils.IpManager;
import cn.com.williamxia.wipack.utils.SomethingMsg;
import cn.com.williamxia.wipack.utils.qDebug;
import comcontrol.VrChanelList;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link Page_DspChanel#newInstance} factory method to
 * create an instance of this fragment.
 */
public class Page_DspChanel extends Fragment implements View.OnClickListener {


    public Page_DspChanel() {
        // Required empty public constructor


    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        registerDspReceiver();


    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View mview = inflater.inflate(R.layout.fragment_page_dsp_chanel, container, false);
        initGUI(mview);
        return mview;

    }

    private Button btnIMute;
    private CSlider fdInut;
    private TextView edInput;
    private Button btnOMute;
    private CSlider fdOuput;
    private TextView edOutput;
    //
    private Button ibtnSel;
    private Button obtnSel;


    private void initGUI(View mview) {
        btnIMute = (Button) mview.findViewById(R.id.btnIMute);
        btnIMute.setOnClickListener(this);
        fdInut = (CSlider) mview.findViewById(R.id.fdInut);
        edInput = (TextView) mview.findViewById(R.id.edInput);
        btnOMute = (Button) mview.findViewById(R.id.btnOMute);
        btnOMute.setOnClickListener(this);
        fdOuput = (CSlider) mview.findViewById(R.id.fdOuput);
        edOutput = (TextView) mview.findViewById(R.id.edOutput);
        //-----
        ibtnSel = (Button) mview.findViewById(R.id.iBtnSel);
        ibtnSel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!mchlistPopWd.isShowing()) {
                    mchlistPopWd.showAsDropDown(view, 0, 0);
                    mchanlListV.iTag = 0;
                    view.setActivated(true);
                }

            }
        });
        obtnSel = (Button) mview.findViewById(R.id.oBtnSel);
        obtnSel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!mchlistPopWd.isShowing()) {
                    mchanlListV.iTag = 1;
                    mchlistPopWd.showAsDropDown(view, 0, 0);
                    view.setActivated(true);
                }

            }
        });


        //------
        fdInut.setChangeListenner(new CSlider.SliderChangeListenner() {
            @Override
            public void onSliderTouchDown(Object sender) {

            }

            @Override
            public void onSliderChange(Object sender, int pvalue) {
                qDebug.qLog("fdout slider value is " + pvalue);
                CSlider slider = (CSlider) sender;
                int index = Integer.parseInt(slider.getTag().toString());
                int chindex = XData.gInstance().iChindex;
                XData.gInstance().m_chEdit[chindex].chGain = pvalue;
                if (TCPClient.getInstance().isConnected()) {
                    XData.gInstance().sendCMD_FaderGain(chindex, IpManager.getInstance().getSelDevID());

                } else {

                    refreshFader(true);
                }

            }
        });
        fdOuput.setChangeListenner(new CSlider.SliderChangeListenner() {
            @Override
            public void onSliderTouchDown(Object sender) {

            }

            @Override
            public void onSliderChange(Object sender, int pvalue) {
                qDebug.qLog("fdout slider value is " + pvalue);
                CSlider slider = (CSlider) sender;
                int index = Integer.parseInt(slider.getTag().toString());
                int chindex = XData.gInstance().oChindex + DStatic.ChanlMax;
                XData.gInstance().m_chEdit[chindex].chGain = pvalue;
                if (TCPClient.getInstance().isConnected()) {
                    XData.gInstance().sendCMD_FaderGain(chindex, IpManager.getInstance().getSelDevID());
                } else {
                    slider.setValue(pvalue);
                    refreshFader(false);
                }


            }
        });
        initPopupWindow();

    }

    @Override
    public void onClick(View view) {  //only for mute btn click
        Button btn = (Button) view;
        int index = Integer.parseInt(btn.getTag().toString());
        int chindex = 0;
        byte tmp = 0;
        if (btn.isActivated()) {
            tmp = 0;
        } else {
            tmp = 1;
        }
        if (index == 0)//input
        {            // XData.gInstance().iChindex=
            chindex = XData.gInstance().iChindex;
        } else {
            chindex = XData.gInstance().oChindex + DStatic.ChanlMax;
        }
        //-----
        XData.gInstance().m_chEdit[chindex].chMute = tmp;

        if (TCPClient.getInstance().isConnected()) {
            qDebug.qLog("chanel mute value is : " + tmp + "  chanlindex is  " + chindex);
            XData.gInstance().sendCMD_ChanlMute(IpManager.getInstance().getSelDevID());
        } else {
            refreshMuteBtn();
        }


    }

    public void refreshMuteBtn() {
        // btnIMute
        byte imute = XData.gInstance().iMute();
        byte omute = XData.gInstance().oMute();
        //
        qDebug.qLog("inmute is : " + imute + " omute is : " + omute);
        btnIMute.setActivated(imute > 0);
        btnOMute.setActivated(omute > 0);

    }

    public void refreshFader(boolean isNeedSetFader) {

        if (isNeedSetFader) {
            int iGain = XData.gInstance().iGain();
            int oGain = XData.gInstance().oGain();

            fdInut.setValue(iGain);
            fdOuput.setValue(oGain);
        }
        //
        edInput.setText(XData.gInstance().strIGain());
        edOutput.setText(XData.gInstance().strOGain());
    }

    public void refreshChannel() {
        String strIn = XData.gInstance().strIchSel();
        String strOu = XData.gInstance().strOchSel();
        ibtnSel.setText(strIn);
        obtnSel.setText(strOu);
    }

    private PopupWindow mchlistPopWd;
    VrChanelList mchanlListV;

    private void initPopupWindow() {

        mchanlListV = new VrChanelList(getContext());
        mchlistPopWd = new PopupWindow(mchanlListV, 200, 320);
        mchlistPopWd.setOutsideTouchable(true);
        mchlistPopWd.setAnimationStyle(android.R.style.Animation_Activity);
        mchlistPopWd.update();
        mchlistPopWd.setTouchable(true);
        mchlistPopWd.setFocusable(true);
        //-----
        mchanlListV.setmViewSelectChanlIndex(new VrChanelList.ChanelViewSelectListener() {
            @Override
            public void onViewSelectChanelIndex(final int itag, final int index) {
                mchlistPopWd.dismiss();
                qDebug.qLog("listview click with itag is :" + itag + " index" + index);

                getActivity().runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (itag == 0) {
                            XData.gInstance().iChindex = index;
                            ibtnSel.setText(DStatic.StrChanelList[index]);
                        } else {
                            XData.gInstance().oChindex = index;
                            obtnSel.setText(DStatic.StrChanelList[index]);

                        }
                        refreshMuteBtn();
                        refreshFader(true);
                    }
                });

            }
        });


    }


    public void refreshWholePage() {
        qDebug.qLog("begin running dsp channel refresh whole page now..");
        refreshFader(true);
        refreshMuteBtn();
        refreshChannel();
        qDebug.qLog("over running dsp channel refresh whole page ....");
    }


    @Override
    public void onDestroy() {
        super.onDestroy();
        unRegisterDspReceiver();
    }

    private void registerDspReceiver() {
        IntentFilter filter = new IntentFilter(DStatic.Action_DspChanelFrag);
        getActivity().registerReceiver(dspChanelReceiver, filter);

    }

    private void unRegisterDspReceiver() {
        getActivity().unregisterReceiver(dspChanelReceiver);
    }

    private BroadcastReceiver dspChanelReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent.getAction().equals(DStatic.Action_DspChanelFrag)) {
                final SomethingMsg msg = (SomethingMsg) intent.getSerializableExtra(DStatic.Msg_Key_DspChanel);
                qDebug.qLog("dsp channel receiver.............now....");
                if (msg.fID.equals(DStatic.Msg_ID_DspChanel)) {

                    switch (msg.HValue) {
                        case Command.F_Mute: {
                            //begin update mute
                            getActivity().runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    refreshMuteBtn();
                                }
                            });
                        }
                        break;
                        case Command.F_InpuGain:
                        case Command.F_OutputGain: {
                            //begin update channel gain
                            refreshFader(true);
                        }
                        break;
                        case DStatic.CPageUPdate:
                            refreshWholePage();
                            break;

                    }


                }

            }
        }


    };
}
