package WinPages;


import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;

import Datas.Command;
import Datas.DStatic;
import Datas.XData;
import cn.com.williamxia.matrixa8.R;
import cn.com.williamxia.wipack.control.HScrollViewX;
import cn.com.williamxia.wipack.control.ScrollListener;
import cn.com.williamxia.wipack.control.ScrollViewX;
import cn.com.williamxia.wipack.socket.TCPClient;
import cn.com.williamxia.wipack.utils.IpManager;
import cn.com.williamxia.wipack.utils.SomethingMsg;
import cn.com.williamxia.wipack.utils.qDebug;
import comcontrol.CSingleVrButonGroup;

import static Datas.XData.gInstance;
import static cn.com.williamxia.matrixa8.R.id.hrScroll;
import static cn.com.williamxia.matrixa8.R.id.mMatrixScrV;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link Page_Matrix#newInstance} factory method to
 * create an instance of this fragment.
 */
public class Page_Matrix extends Fragment implements CSingleVrButonGroup.SingleMatrixClickListener {


    public Page_Matrix() {
        // Required empty public constructor
    }


    @Override
    public void onDestroy() {
        super.onDestroy();
        getActivity().unregisterReceiver(mMatrixRecever);

    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        IntentFilter filter = new IntentFilter(DStatic.Action_MatrixFrag);
        getActivity().registerReceiver(mMatrixRecever, filter);
    }

    public void updateSingleMatrix(final int chindex) {
        if (chindex >= 0 && chindex < mgroupList.size()) {
            mgroupList.get(chindex).refreshAll_buttonState();

        }


    }

    private BroadcastReceiver mMatrixRecever = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent.getAction().equals(DStatic.Action_MatrixFrag)) {
                final SomethingMsg msg = (SomethingMsg) intent.getSerializableExtra(DStatic.Msg_Key_Matrix);
                if (msg.fID.equals(DStatic.Msg_ID_Matrix)) {
                    switch (msg.HValue) {
                        case Command.F_MatrixMixer:
                            //begin update matrix
                        {
                            final int chindex = msg.LValue;
                            qDebug.qLog("matrix recievc chindex is :" + chindex);
                            getActivity().runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    updateSingleMatrix(chindex);
                                }
                            });

                        }
                        break;
                        case DStatic.CPageUPdate:
                            getActivity().runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    refreshWholePage();
                                }
                            });

                            break;

                    }

                }


            }

        }

    };


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View mview = inflater.inflate(R.layout.fragment_page_matrix, container, false);
        initGUI(mview);

        return mview;

    }

    @Override
    public void onStart() {
        super.onStart();
        refreshWholePage();
    }

    ScrollViewX mScrolv;
    HScrollViewX mHScrolv;
    private HScrollViewX topLbScrol;
    private ScrollViewX leftLbScroll;

    private void initGUI(View mv) {
        topLbScrol = (HScrollViewX) mv.findViewById(R.id.topLbScrol);
        leftLbScroll = (ScrollViewX) mv.findViewById(R.id.leftLbScroll);

        mScrolv = (ScrollViewX) mv.findViewById(mMatrixScrV);
        mScrolv.setScrollListener(new ScrollListener() {
            @Override
            public void onScrollChanged(int nx, int ny, int oldX, int oldY) {

                leftLbScroll.setScrollY(ny);
            }

            @Override
            public void onScrollStopped() {

            }

            @Override
            public void onScrolling() {
                //  qDebug.qLog("scrollview is scrolling.....");
            }
        });


        mHScrolv = (HScrollViewX) mv.findViewById(hrScroll);
        mHScrolv.setScrollListener(new ScrollListener() {
            @Override
            public void onScrollChanged(int nx, int ny, int oldX, int oldY) {
                //  qDebug.qLog("horizontal scrollview is changeed  with nx :  " + nx + "   ny " + ny);
                topLbScrol.setScrollX(nx);
            }

            @Override
            public void onScrollStopped() {

            }

            @Override
            public void onScrolling() {
                // qDebug.qLog("scrollview is scrolling.....");
            }
        });
        //  qDebug.qLog("begin initial in created view in fragment...");
        initSingleGroups(mv);
    }

    public void refreshWholePage() {
        CSingleVrButonGroup mgroup = null;
        for (int i = 0; i < 20; i++) {
            mgroup = mgroupList.get(i);
           System.arraycopy( XData.gInstance().m_matrixAry[i],0,mgroup.m_vrValue,0,20);
            mgroup.refreshAll_buttonState();
        }

    }


    private CSingleVrButonGroup singleGroup0;
    private CSingleVrButonGroup singleGroup1;
    private CSingleVrButonGroup singleGroup2;
    private CSingleVrButonGroup singleGroup3;
    private CSingleVrButonGroup singleGroup4;
    private CSingleVrButonGroup singleGroup5;
    private CSingleVrButonGroup singleGroup6;
    private CSingleVrButonGroup singleGroup7;
    private CSingleVrButonGroup singleGroup8;
    private CSingleVrButonGroup singleGroup9;
    private CSingleVrButonGroup singleGroup10;
    private CSingleVrButonGroup singleGroup11;
    private CSingleVrButonGroup singleGroup12;
    private CSingleVrButonGroup singleGroup13;
    private CSingleVrButonGroup singleGroup14;
    private CSingleVrButonGroup singleGroup15;
    private CSingleVrButonGroup singleGroup16;
    private CSingleVrButonGroup singleGroup17;
    private CSingleVrButonGroup singleGroup18;
    private CSingleVrButonGroup singleGroup19;

    private ArrayList<CSingleVrButonGroup> mgroupList = new ArrayList<CSingleVrButonGroup>();

    private void initSingleGroups(View mv) {
        if (mgroupList == null)
            mgroupList = new ArrayList<CSingleVrButonGroup>();
        else
            mgroupList.clear();
        singleGroup0 = (CSingleVrButonGroup) mv.findViewById(R.id.singleGroup_0);
        singleGroup1 = (CSingleVrButonGroup) mv.findViewById(R.id.singleGroup_1);
        singleGroup2 = (CSingleVrButonGroup) mv.findViewById(R.id.singleGroup_2);
        singleGroup3 = (CSingleVrButonGroup) mv.findViewById(R.id.singleGroup_3);
        singleGroup4 = (CSingleVrButonGroup) mv.findViewById(R.id.singleGroup_4);
        singleGroup5 = (CSingleVrButonGroup) mv.findViewById(R.id.singleGroup_5);
        singleGroup6 = (CSingleVrButonGroup) mv.findViewById(R.id.singleGroup_6);
        singleGroup7 = (CSingleVrButonGroup) mv.findViewById(R.id.singleGroup_7);
        singleGroup8 = (CSingleVrButonGroup) mv.findViewById(R.id.singleGroup_8);
        singleGroup9 = (CSingleVrButonGroup) mv.findViewById(R.id.singleGroup_9);
        singleGroup10 = (CSingleVrButonGroup) mv.findViewById(R.id.singleGroup_10);
        singleGroup11 = (CSingleVrButonGroup) mv.findViewById(R.id.singleGroup_11);
        singleGroup12 = (CSingleVrButonGroup) mv.findViewById(R.id.singleGroup_12);
        singleGroup13 = (CSingleVrButonGroup) mv.findViewById(R.id.singleGroup_13);
        singleGroup14 = (CSingleVrButonGroup) mv.findViewById(R.id.singleGroup_14);
        singleGroup15 = (CSingleVrButonGroup) mv.findViewById(R.id.singleGroup_15);
        singleGroup16 = (CSingleVrButonGroup) mv.findViewById(R.id.singleGroup_16);
        singleGroup17 = (CSingleVrButonGroup) mv.findViewById(R.id.singleGroup_17);
        singleGroup18 = (CSingleVrButonGroup) mv.findViewById(R.id.singleGroup_18);
        singleGroup19 = (CSingleVrButonGroup) mv.findViewById(R.id.singleGroup_19);
//
        mgroupList.add(singleGroup0);
        mgroupList.add(singleGroup1);
        mgroupList.add(singleGroup2);
        mgroupList.add(singleGroup3);
        mgroupList.add(singleGroup4);
        //
        mgroupList.add(singleGroup5);
        mgroupList.add(singleGroup6);
        mgroupList.add(singleGroup7);
        mgroupList.add(singleGroup8);
        mgroupList.add(singleGroup9);//
        //
        mgroupList.add(singleGroup10);
        mgroupList.add(singleGroup11);
        mgroupList.add(singleGroup12);
        mgroupList.add(singleGroup13);
        mgroupList.add(singleGroup14);
        //
        mgroupList.add(singleGroup15);
        mgroupList.add(singleGroup16);
        mgroupList.add(singleGroup17);
        mgroupList.add(singleGroup18);
        mgroupList.add(singleGroup19);//
        CSingleVrButonGroup mgroup = null;
        for (int i = 0; i < 20; i++) {
            mgroup = mgroupList.get(i);
            mgroup.setSingleMatrixClickListener(this);
        }

    }

    @Override
    public void OnSingleMatrixClick(CSingleVrButonGroup sender, int col, int row) {
        //----
        qDebug.qLog("on slingle matrix clik col " + col + "  row is " + row);
        gInstance().m_matrixAry[row][col] = sender.m_vrValue[col];
        if (TCPClient.getInstance().isConnected()) {
            gInstance().sendCMD_matrixWithChanel(row, IpManager.getInstance().getSelDevID());
        } else {
            sender.refreshAll_buttonState();

        }

    }
}
