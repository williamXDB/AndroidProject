package WinPages;

import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.github.ybq.android.spinkit.SpinKitView;
import com.gitonway.lee.niftymodaldialogeffects.lib.Effectstype;
import com.gitonway.lee.niftymodaldialogeffects.lib.NiftyDialogBuilder;
import com.zhy.autolayout.AutoLinearLayout;

import java.io.File;
import java.text.DecimalFormat;
import java.util.ArrayList;

import Adapters.CLocalPresetInfo;
import Adapters.SavePresetToDeviceAdapter;
import Adapters.SavePresetToPCAdapter;
import Datas.CFinalStr;
import Datas.CmdSender;
import Datas.Command;
import Datas.DStatic;
import Datas.XData;
import cn.com.williamxia.matrixa8.R;
import cn.com.williamxia.wipack.socket.TCPClient;
import cn.com.williamxia.wipack.utils.CIOBean;
import cn.com.williamxia.wipack.utils.CIOBeanOpreation;
import cn.com.williamxia.wipack.utils.IpManager;
import cn.com.williamxia.wipack.utils.SomethingMsg;
import cn.com.williamxia.wipack.utils.qDebug;
import kr.co.namee.permissiongen.PermissionFail;
import kr.co.namee.permissiongen.PermissionGen;
import kr.co.namee.permissiongen.PermissionSuccess;

import static cn.com.williamxia.wipack.utils.CIOBeanOpreation.readBean_fromStoreageCard;

/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link Page_Preset.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link Page_Preset#newInstance} factory method to
 * create an instance of this fragment.
 */
public class Page_Preset extends Fragment {
    private SavePresetToDeviceAdapter deviceAdapter;
    private SavePresetToPCAdapter localAdapter;
    private ArrayList<String> mDevPresetList;
    private ArrayList<CLocalPresetInfo> mLocalPreFileList;

    public Page_Preset() {
        // Required empty public constructor

    }

    private BroadcastReceiver mPresetReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent.getAction().equals(DStatic.Action_Preset)) {
                final SomethingMsg msg = (SomethingMsg) intent.getSerializableExtra(DStatic.Msg_Key_Preset);
                if (msg.fID.equals(DStatic.Msg_ID_Preset)) {
                    switch (msg.HValue) {
                        case Command.F_GetPresetList: {
                            getActivity().runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    refreshGUI_presetList(gRCheckTag());
                                    setIndecatorSpinStatus(false);
                                }
                            });
                            qDebug.qLog("refresh presetlist now.......");
                        }
                        break;
                        case Command.F_RecallCurrentScene: {
                            setIndecatorSpinStatus(false);
                        }

                        break;
                        case Command.F_MemoryExport://read dats to local return
                        {
                            int index = msg.LValue;
                            qDebug.qLog("receive package seg is " + index);
                            setPreTxt(edImptAllPresets, index);
                            if (index == DStatic.Memory_Max_Package - 1)//0..23
                            {
                                saveAllMemoryToLocal(DStatic.MemPresetsName, XData.gInstance().m_meoryRead);
                                btnImptAllPrests.setEnabled(true);
                                btnExportAllPrests.setEnabled(true);
                                rightArea.setEnabled(true);
                            } else {
                                btnExportAllPrests.setEnabled(false);
                                rightArea.setEnabled(false);
                            }
                        }
                        break;
                        case Command.F_MemoryImportAck: {
                            int index = msg.LValue;
                            setPreTxt(edExportPresets, index);
                            if (index == DStatic.Memory_Max_Package - 1) {
                                btnImptAllPrests.setEnabled(true);
                                btnExportAllPrests.setEnabled(true);
                                rightArea.setEnabled(true);

                            } else {
                                btnImptAllPrests.setEnabled(false);
                                rightArea.setEnabled(false);
                            }

                        }
                        break;
                        case DStatic.CPageUPdate:
                            refreshGUI_presetList(gRCheckTag());
                            qDebug.qLog("page preset onstart now.....");
                            break;

                    }
                }

            }
        }

    };


    private void saveAllMemoryToLocal(final String fileName, final byte[] bodyData) {

        CIOBean bean = new CIOBean(fileName, bodyData, DStatic.StrMemoryHeader);

        int slen = bean.getBeanData().length;
        qDebug.qLog("wrie bean body data length is : " + slen);
        bean.printBeanData();
        boolean result = CIOBeanOpreation.writeBeanToSDcard(bean, DStatic.SD_Path_SaveLoad);
        //add to list
        if (result) {
            //  qDebug.qLog("write bean success fule so ben add to list");
            Toast.makeText(getActivity(), "Has saved sucessfully!", Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(getActivity(), "Has saved failed!", Toast.LENGTH_LONG).show();
        }

    }


    private void setPreTxt(TextView tv, final int iseg) {
        double seg = (double) (iseg + 1) / DStatic.Memory_Max_Package;
        String str = new DecimalFormat("##%").format(seg);
        tv.setText(str);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        getActivity().unregisterReceiver(mPresetReceiver);
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        IntentFilter filter = new IntentFilter(DStatic.Action_Preset);
        getActivity().registerReceiver(mPresetReceiver, filter);
        init();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View mview = inflater.inflate(R.layout.fragment_page_preset, container, false);
        initGUI(mview);
        return mview;

    }


    private ListView lvSaveLoad;
    private EditText tvStatus;
    private RadioGroup rDevGroup;

    private Button btnSave;
    private Button btnLoad;
    private Button btnDelete;
    private Button btnRecall;
    private SpinKitView saveloadSpin;
    //------
    private TextView edImptAllPresets;
    private Button btnImptAllPrests;
    private TextView edExportPresets;
    private Button btnExportAllPrests;
    private AutoLinearLayout rightArea;

    private void initGUI(final View mview) {


        lvSaveLoad = (ListView) mview.findViewById(R.id.lvSaveLoad);
        tvStatus = (EditText) mview.findViewById(R.id.tvStatus);
        rDevGroup = (RadioGroup) mview.findViewById(R.id.rDevGroup);
        //---------------------------------------
        btnSave = (Button) mview.findViewById(R.id.btnSave);
        btnLoad = (Button) mview.findViewById(R.id.btnLoad);
        btnDelete = (Button) mview.findViewById(R.id.btnDelete);
        btnRecall = (Button) mview.findViewById(R.id.btnRecall);
        saveloadSpin = (SpinKitView) mview.findViewById(R.id.saveloadSpin);

        //
        rDevGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                int rbid = radioGroup.getCheckedRadioButtonId();
                RadioButton rb = (RadioButton) mview.findViewById(rbid);
                int index = Integer.parseInt(rb.getTag().toString());
                refreshGUI_presetList(index);


            }
        });


        //--------------------
        edImptAllPresets = (TextView) mview.findViewById(R.id.edImptAllPresets);
        btnImptAllPrests = (Button) mview.findViewById(R.id.btnImptAllPrests);
        edExportPresets = (TextView) mview.findViewById(R.id.edExportPresets);
        btnExportAllPrests = (Button) mview.findViewById(R.id.btnExportAllPrests);
        rightArea = (AutoLinearLayout) mview.findViewById(R.id.rightArea);
        btnImptAllPrests.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (TCPClient.getInstance().isConnected()) {
                    btnImptAllPrests.setEnabled(false);
                    setIndecatorSpinStatus(true);
                    CmdSender.sendCMD_MemoryExportFromDevice(IpManager.getInstance().getSelDevID());
                    rightArea.setEnabled(false);
                } else {
                    Toast.makeText(getActivity(), "No network connection", Toast.LENGTH_LONG).show();
                }


            }
        });

        btnExportAllPrests.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (TCPClient.getInstance().isConnected()) {
                    btnExportAllPrests.setEnabled(false);
                    setIndecatorSpinStatus(true);
                    loadAllMemoryFile_from_local();
                    rightArea.setEnabled(false);
                } else {
                    Toast.makeText(getActivity(), "No network connection", Toast.LENGTH_LONG).show();
                }
            }
        });

        btnSave.setOnClickListener(svListener);
        btnDelete.setOnClickListener(svListener);
        btnRecall.setOnClickListener(svListener);
        btnLoad.setOnClickListener(svListener);
        //


        lvSaveLoad.setAdapter(deviceAdapter);
        lvSaveLoad.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                if (gRCheckTag() == 0) {
                    deviceAdapter.setmSelectindex(i);
                } else {
                    localAdapter.setmSelectindex(i);
                }
                selectindex = i;
                tvStatus.setText("You select the item position: " + i);

            }
        });

    }

    public void refreshGUI_presetList(int flag) {
        selectindex = -1;
        if (flag == 0) {
            freshPresets_Device();
            lvSaveLoad.setAdapter(deviceAdapter);
            freshStatus_itemindex();

        } else {
            PermissionGen.with(this)
                    .addRequestCode(100)
                    .permissions(
                            Manifest.permission.WRITE_EXTERNAL_STORAGE,
                            Manifest.permission.READ_EXTERNAL_STORAGE)
                    .request();

        }

    }

    @PermissionSuccess(requestCode = 100)
    public void doSomething() {
        selectindex = -1;
        freshPresets_Local();
        freshStatus_itemindex();
        lvSaveLoad.setAdapter(localAdapter);

    }

    @PermissionFail(requestCode = 100)
    public void doFailSomething() {
        Toast.makeText(getActivity(), "Contact permission is not granted", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        doSomething();

    }

    public void setCheckAt(int tg) {
        if (tg >= 0 && tg < 2) {
            BaseAdapter lvAdapter = null;
            if (tg == 0) {
                rDevGroup.check(R.id.rTypeDev);
                lvAdapter = deviceAdapter;
            } else {
                rDevGroup.check(R.id.rTypePc);
                lvAdapter = localAdapter;
            }
            lvSaveLoad.setAdapter(lvAdapter);
        }

    }

    private int selectindex = -1;

    public void listFiles() {

        //
        selectindex = -1;
        mLocalPreFileList.clear();

        File dir = new File(DStatic.SD_Path_SaveLoad);
        if (!dir.exists()) {
            dir.mkdirs();
            qDebug.qLog("make dirs now");
        }
        if (dir.exists()) {
            CIOBean bean = null;
            CLocalPresetInfo localInfo = null;
            File[] files = dir.listFiles();
            if (files != null && files.length > 0) {

                for (int i = 0; i < files.length; i++) {
                    String strFileName = files[i].getName();
                    qDebug.qLog("list file with name " + strFileName);
                    bean = readBean_fromStoreageCard(strFileName, DStatic.SD_Path_SaveLoad);
                    // qDebug.qLog("Bean header is " + mstr);
                    if (bean != null) {
                        int flens = bean.getStrHeader16().length();
                        //   qDebug.qLog("bean head len is : " + flens);
                        if (!bean.getStrHeader16().contains("All")) {
                            localInfo = new CLocalPresetInfo(strFileName);
                            localInfo.mSaveTime = bean.getStrRecordTime();
                            mLocalPreFileList.add(localInfo);
                        }

                    } else {
                        qDebug.qLog("IOBean is nul with i " + i);
                    }


                }
            }

        }
        localAdapter.notifyDataSetChanged();


    }

    public boolean isFileExist(String fileName) {
        File dir = new File(DStatic.SD_Path_SaveLoad, fileName);
        return dir.exists();
    }

    public void freshPresets_Local() {
        listFiles();
        qDebug.qLog("after listfiles the local file preset count is " + mLocalPreFileList.size());
    }

    public void freshPresets_Device() {

        mDevPresetList.clear();
        for (int i = 1; i < XData.Max_Presets; i++) {
            String strUName = XData.gInstance().nameUserPreset(i);
            mDevPresetList.add(strUName);
        }
        deviceAdapter.notifyDataSetChanged();
    }

    public int gRCheckTag() {
        RadioButton rcheckBtn = (RadioButton) rDevGroup.findViewById(rDevGroup.getCheckedRadioButtonId());
        return Integer.parseInt(rcheckBtn.getTag().toString());
    }

    private SaveLoadBtnListener svListener;

    private void init() {
        svListener = new SaveLoadBtnListener();
        mDevPresetList = new ArrayList<String>();
        mLocalPreFileList = new ArrayList<CLocalPresetInfo>();
        deviceAdapter = new SavePresetToDeviceAdapter(getActivity(), mDevPresetList);
        localAdapter = new SavePresetToPCAdapter(getActivity(), mLocalPreFileList);
    }

    private EditText ed_input;//for saveDialog

    public void showSaveDialog(final int flag) {

        final NiftyDialogBuilder dialogBuilder = NiftyDialogBuilder.getInstance(getActivity());
        String strTitle = null;
        if (flag == 0)
            strTitle = "Save preset name.";
        else
            strTitle = "Save preset file name.";
        dialogBuilder
                .withTitle(strTitle)                                  //.withTitle(null)  no title
                .withTitleColor("#FFFFFF")
                .withDividerColor("#11000000")
                .withMessage(null)                     //.withMessage(null)  no Msg
                .withMessageColor("#FFFFFFFF")                              //withMessageColor(int resid)
                .withDialogColor("#373737")                               //withDialogColor(int resid)                               //def
                .withIcon(R.drawable.icon)
                .isCancelableOnTouchOutside(false)                           //isCancelable(true)
                .withDuration(800)                                          //
                .withEffect(Effectstype.RotateLeft)                         //def Effectstype.Slidetop
                .withButton1Text("OK")
                .withButton2Text("Cancel")
                .setCustomView(R.layout.item_saveload_dialog, getActivity())         //.setCustomView(View or ResId,context)

                .setButton1Click(new View.OnClickListener() {
                    //  InputFilter[] filters = {new InputFilter.LengthFilter(10)};
//                    ed_input.setFilters(filters);
                    @Override
                    public void onClick(View v) {

                        ed_input = (EditText) dialogBuilder.tempView.findViewById(R.id.ed_input);
                        String sNewDevName = ed_input.getText().toString().trim();
                        qDebug.qLog("you input the new name is : " + sNewDevName);
                        if (gRCheckTag() == 0) {
                            if (selectindex >= 0 && selectindex < XData.Max_Presets) {

                                XData.gInstance().setUserPresetName(sNewDevName, selectindex);
                                if (TCPClient.getInstance().isConnected()) {
                                    setIndecatorSpinStatus(true);
                                    XData.gInstance().sendCMD_SavePresetWithName(selectindex, IpManager.getInstance().getSelDevID());

                                }
                            } else {
                                Toast.makeText(getActivity(), CFinalStr.No_ItemChoose, Toast.LENGTH_LONG).show();

                            }

                        } else {
                            saveCurrentSence_to_local(sNewDevName);
                            selectindex = -1;
                            freshPresets_Local();
                        }

                        dialogBuilder.dismiss();
                    }

                })
                .setButton2Click(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        dialogBuilder.dismiss();
                    }
                })
                .show();

    }

    private void saveCurrentSence_to_local(String fileName) {

        byte[] bodyData = XData.gInstance().gPackageofLoad();
        CIOBean bean = new CIOBean(fileName, bodyData, DStatic.StrPresetHeader);

        int slen = bean.getBeanData().length;
        qDebug.qLog("wrie bean body data length is : " + slen);
        bean.printBeanData();
        boolean result = CIOBeanOpreation.writeBeanToSDcard(bean, DStatic.SD_Path_SaveLoad);
        //add to list
        if (result) {
            //  qDebug.qLog("write bean success fule so ben add to list");
            CLocalPresetInfo cpf = new CLocalPresetInfo(fileName);
            cpf.mSaveTime = bean.getStrRecordTime();
            mLocalPreFileList.add(cpf);
            lvSaveLoad.setAdapter(localAdapter);
            localAdapter.notifyDataSetChanged();
        }


    }

    public void setIndecatorSpinStatus(boolean isVisible) {
        saveloadSpin.setVisibility(isVisible ? View.VISIBLE : View.INVISIBLE);

    }

    //--------------listener
    public class SaveLoadBtnListener implements View.OnClickListener {
        @Override
        public void onClick(View view) {
            //--------------------------
            final int btnID = view.getId();
            switch (btnID) {
                case R.id.btnSave: {
                    showSaveDialog(gRCheckTag());
                }
                break;
                case R.id.btnLoad: {
                    if (!TCPClient.getInstance().isConnected()) {
                        Toast.makeText(getActivity(), CFinalStr.No_NetWork, Toast.LENGTH_LONG).show();
                        return;
                    }

                    if (gRCheckTag() == 0) {   //load from device list
                        if (selectindex >= 0)
                            CmdSender.sendCMD_RecallSinglePreset(selectindex, IpManager.getInstance().getSelDevID());
                        else {
                            Toast.makeText(getActivity(), CFinalStr.No_ItemChoose, Toast.LENGTH_LONG).show();
                        }

                    } else { //load from local
                        if (selectindex >= 0)
                            loadPackage_from_local(selectindex);
                        else {
                            Toast.makeText(getActivity(), CFinalStr.No_ItemChoose, Toast.LENGTH_LONG).show();

                        }
                    }
                    // } else {
                    //   Toast.makeText(getActivity(), "No connected ", Toast.LENGTH_LONG).show();
                    // }
                }
                break;
                case R.id.btnDelete:
                    if (selectindex < 0) {
                        Toast.makeText(getActivity(), CFinalStr.No_ItemChoose, Toast.LENGTH_LONG).show();
                    } else {
                        if (gRCheckTag() == 0) {
                            if (TCPClient.getInstance().isConnected()) {
                                //begin spin status true
                                if (selectindex >= 0) {
                                    CmdSender.sendCMD_DeleteSinglePreset(selectindex, IpManager.getInstance().getSelDevID());
                                    setIndecatorSpinStatus(true);
                                    selectindex = -1;
                                } else {
                                    Toast.makeText(getActivity(), CFinalStr.No_ItemChoose, Toast.LENGTH_LONG).show();

                                }


                            } else {
                                Toast.makeText(getActivity(), CFinalStr.No_NetWork, Toast.LENGTH_LONG).show();
                            }

                        } else {
                            String fileName = mLocalPreFileList.get(selectindex).mFileName;
                            //    qDebug.qLog("select delete fielname is " + fileName);
                            fdeleteFile(fileName);
                            freshStatus_itemindex();

                        }
                    }


                    break;

                case R.id.btnRecall: {
                    if (TCPClient.getInstance().isConnected()) {
                        setIndecatorSpinStatus(true);
                    } else {
                        Toast.makeText(getActivity(), CFinalStr.No_NetWork, Toast.LENGTH_LONG).show();
                        return;
                    }
                    CmdSender.sendCMD_ReadPresetList(IpManager.getInstance().getSelDevID());
                    qDebug.qLog("btn recall do now...");
                }

                break;

            }


        }
    }

    public void fdeleteFile(final String fileName) {
        File mfile = new File(DStatic.SD_Path_SaveLoad, fileName);
        if (mfile.exists()) {

            mfile.delete();
            // qDebug.qLog("file delete name is " + mfile.getAbsoluteFile());
            localAdapter.setmSelectindex(-1);
            listFiles();
        }

    }

    public void freshStatus_itemindex() {
        tvStatus.setText("Current position  " + selectindex);
    }

    public void loadPackage_from_local(int preindex) {

        String strFileName = mLocalPreFileList.get(preindex).mFileName;
        CIOBean bean = readBean_fromStoreageCard(strFileName, DStatic.SD_Path_SaveLoad);
        if (bean == null) {
            Toast.makeText(getActivity(), "The file preset loaded fauilure,may be the file has lost.", Toast.LENGTH_SHORT).show();
        } else {
            int len = bean.getBeanData().length;
            //  qDebug.qLog("has load the bean length is " + len);
            //   bean.printBeanData();
            XData.gInstance().iRead_CurrentScene(bean.getBeanData(), true);
            if (TCPClient.getInstance().isConnected())
                setIndecatorSpinStatus(true);
            CmdSender.sendCMD_loadFromLocalToDevice(bean.getBeanData(), IpManager.getInstance().getSelDevID());

        }


    }

    public void loadAllMemoryFile_from_local() {

        CIOBean bean = readBean_fromStoreageCard(DStatic.MemPresetsName, DStatic.SD_Path_SaveLoad);
        if (bean == null) {
            Toast.makeText(getActivity(), "The memory file loaded fauilure,may be the file has lost.", Toast.LENGTH_SHORT).show();
        } else {
            int len = bean.getBeanData().length;
            //  qDebug.qLog("has load the bean length is " + len);
            //   bean.printBeanData();
            XData.gInstance().m_meoryRead = bean.getBeanData();

            if (TCPClient.getInstance().isConnected()) {
                setIndecatorSpinStatus(true);
                XData.gInstance().sendCMD_LoadPresteFlile_fromLocal(0);
            }
            qDebug.qLog("Begin load all memory file from local to device now.......");


        }


    }

}
