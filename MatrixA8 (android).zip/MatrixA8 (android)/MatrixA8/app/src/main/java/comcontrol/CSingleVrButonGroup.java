package comcontrol;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

import java.util.ArrayList;

import cn.com.williamxia.matrixa8.R;
import cn.com.williamxia.wipack.utils.qDebug;

/**
 * Created by williamXia on 2017/11/21.
 */

public class CSingleVrButonGroup extends LinearLayout implements View.OnClickListener {

    private int iTag;
    public byte m_vrValue[];

    public static final int Max_singleNum = 20;

    public CSingleVrButonGroup(Context context) {
        this(context, null);
    }

    public CSingleVrButonGroup(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public CSingleVrButonGroup(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        LayoutInflater inflater = LayoutInflater.from(context);
        inflater.inflate(R.layout.vr_single_matrix, this);
        TypedArray resAry = null;
        initParameter();
        try {
            //----
            resAry = context.getTheme().obtainStyledAttributes(attrs, R.styleable.CSingleVrButonGroup, defStyleAttr, 0);
            int atrCount = resAry.getIndexCount();
            for (int i = 0; i < atrCount; i++) {
                int index = resAry.getIndex(i);
                if (index == R.styleable.CSingleVrButonGroup_matrix_group_tag)
                    iTag = resAry.getInteger(index, 0);
            }
        } finally {
            searchButtons();
            resAry.recycle();
           // qDebug.qLog("itag is "+iTag);
        }

    }

    private void initParameter() {
        m_vrValue = new byte[Max_singleNum];
        iTag = 0;
        initAllBtns(this);
    }

    private SingleMatrixClickListener singleMatrixClickListener;

    public void setSingleMatrixClickListener(SingleMatrixClickListener singleMatrixClickListener) {
        this.singleMatrixClickListener = singleMatrixClickListener;
    }

    public void searchButtons() {

        int count=btnList.size();
       // qDebug.qLog("search button number is "+count);
        for (int i = 0; i < count; i++) {
            Button mbtn = btnList.get(i);
            mbtn.setOnClickListener(this);

        }

    }

    private Button vrBtn0;
    private Button vrBtn1;
    private Button vrBtn2;
    private Button vrBtn3;
    private Button vrBtn4;
    private Button vrBtn5;
    private Button vrBtn6;
    private Button vrBtn7;
    private Button vrBtn8;
    private Button vrBtn9;
    private Button vrBtn10;
    private Button vrBtn11;
    private Button vrBtn12;
    private Button vrBtn13;
    private Button vrBtn14;
    private Button vrBtn15;
    private Button vrBtn16;
    private Button vrBtn17;
    private Button vrBtn18;
    private Button vrBtn19;

    private ArrayList<Button> btnList=new ArrayList<Button>();
    private void  initAllBtns(View mv) {
        vrBtn0 = (Button) mv.findViewById(R.id.vrBtn_0);
        vrBtn1 = (Button) mv.findViewById(R.id.vrBtn_1);
        vrBtn2 = (Button) mv.findViewById(R.id.vrBtn_2);
        vrBtn3 = (Button) mv.findViewById(R.id.vrBtn_3);
        vrBtn4 = (Button) mv.findViewById(R.id.vrBtn_4);
        vrBtn5 = (Button) mv.findViewById(R.id.vrBtn_5);
        vrBtn6 = (Button) mv.findViewById(R.id.vrBtn_6);
        vrBtn7 = (Button) mv.findViewById(R.id.vrBtn_7);
        vrBtn8 = (Button) mv.findViewById(R.id.vrBtn_8);
        vrBtn9 = (Button) mv.findViewById(R.id.vrBtn_9);
        vrBtn10 = (Button) mv.findViewById(R.id.vrBtn_10);
        vrBtn11 = (Button) mv.findViewById(R.id.vrBtn_11);
        vrBtn12 = (Button) mv.findViewById(R.id.vrBtn_12);
        vrBtn13 = (Button) mv.findViewById(R.id.vrBtn_13);
        vrBtn14 = (Button) mv.findViewById(R.id.vrBtn_14);
        vrBtn15 = (Button) mv.findViewById(R.id.vrBtn_15);
        vrBtn16 = (Button) mv.findViewById(R.id.vrBtn_16);
        vrBtn17 = (Button) mv.findViewById(R.id.vrBtn_17);
        vrBtn18 = (Button) mv.findViewById(R.id.vrBtn_18);
        vrBtn19 = (Button) mv.findViewById(R.id.vrBtn_19);
        btnList.add(vrBtn0);
        btnList.add(vrBtn1);
        btnList.add(vrBtn2);
        btnList.add(vrBtn3);
        btnList.add(vrBtn4);
        btnList.add(vrBtn5);
        btnList.add(vrBtn6);//
        btnList.add(vrBtn7);
        btnList.add(vrBtn8);
        btnList.add(vrBtn9);
        btnList.add(vrBtn10);
        btnList.add(vrBtn11);
        btnList.add(vrBtn12);
        //
        btnList.add(vrBtn13);
        btnList.add(vrBtn14);
        btnList.add(vrBtn15);
        btnList.add(vrBtn16);
        btnList.add(vrBtn17);//
        btnList.add(vrBtn18);
        btnList.add(vrBtn19);


    }


    public void refreshAll_buttonState() {

        int count = btnList.size();
        for (int i = 0; i < count; i++) {
            Button mbtn = btnList.get(i);
              mbtn.setActivated((m_vrValue[i]>0));

         }

    }


    @Override
    public void onClick(View view) {
        Button mbtn = (Button) view;
        int index = Integer.parseInt(mbtn.getTag().toString());
        byte tmp = 0;
        if (mbtn.isActivated()) {
            tmp = 0;
        } else {
            tmp = 1;

        }
        m_vrValue[index] = tmp;
        if (singleMatrixClickListener != null)
            singleMatrixClickListener.OnSingleMatrixClick(this,index, iTag);
        else
        {
            qDebug.qLog("this vrbuttongroup listenner is null... "+iTag);

        }
        qDebug.qLog("single matrix onclick with col :" + index + "  row " + iTag+"   tmpvalue "+tmp);
    }

    public int getiTag() {
        return iTag;
    }

    public void setiTag(int iTag) {
        this.iTag = iTag;

    }

    public interface SingleMatrixClickListener {
        public void OnSingleMatrixClick(CSingleVrButonGroup sender,final int col, final int tag);


    }


}
