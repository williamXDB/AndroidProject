package comcontrol;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.LinearLayout;
import android.widget.ListView;

import Adapters.ChanelListAdapter;
import cn.com.williamxia.matrixa8.R;
import cn.com.williamxia.wipack.utils.qDebug;

/**
 * Created by williamXia on 2017/11/23.
 */


public class VrChanelList extends LinearLayout {

    private ChanelListAdapter mAdapter;
    public int iTag;


    public VrChanelList(Context context) {
        this(context, null);
    }


    public VrChanelList(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public VrChanelList(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        LayoutInflater inflater = LayoutInflater.from(context);
        inflater.inflate(R.layout.item_chanl_list, this);
        //
        initGUI();
        TypedArray resAry = null;
        try {
            //resAry=context.getTheme().obtainStyledAttributes(attrs,R)

        } finally {
            if (resAry != null)
                resAry.recycle();


        }


    }
    //-------

    private ListView chlistV;

    public void initGUI() {
        chlistV = (ListView) findViewById(R.id.chlistV);
        mAdapter = new ChanelListAdapter(getContext());
        chlistV.setAdapter(mAdapter);
        //
        chlistV.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                qDebug.qLog("list view on click with i " + i + "  long " + l);
                mAdapter.setmSelectindex(i);
                if (mViewSelectChanlIndex != null) {
                    mViewSelectChanlIndex.onViewSelectChanelIndex(iTag, i);
                }

            }
        });

    }

    private ChanelViewSelectListener mViewSelectChanlIndex;


    public ChanelViewSelectListener getmViewSelectChanlIndex() {
        return mViewSelectChanlIndex;
    }

    public void setmViewSelectChanlIndex(ChanelViewSelectListener mViewSelectChanlIndex) {
        this.mViewSelectChanlIndex = mViewSelectChanlIndex;
    }

    public interface ChanelViewSelectListener {
        public void onViewSelectChanelIndex(final int flag, final int index);


    }


}
