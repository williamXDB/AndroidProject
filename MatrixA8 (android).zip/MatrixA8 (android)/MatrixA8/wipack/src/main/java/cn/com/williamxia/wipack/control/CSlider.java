package cn.com.williamxia.wipack.control;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

import cn.com.williamxia.wipack.R;
import cn.com.williamxia.wipack.utils.qDebug;


/**
 * Created by williamXia on 2017/8/2.
 */

public class CSlider extends View {


    private static final float def_tailGap = 2.0f;
    private static final float def_bottomGap = 3.0f;
    private static final float def_headGap = 2.0f;
    private static final float def_dockTop = 3.0f;
    private static final float def_thumbOffset = 0f;
    private static final int def_sliderMax = 100;
    private static final int def_sliderWH = 30;
    private final int KDebug = 1;
    float gapSpace = 0;
    //-for exposed
    private int iTag;
    private Bitmap iThumb;//thumb image for slider
    private int MaxValue;
    private int MinValue;
    private int value;
    private boolean isLevel;//is horizontal
    //
    private float thumbOffset;
    private float dockTopGap;
    private float dockBotomGap;
    private float headerGap;
    private float tailGap;
    //-------tempoaray value
    private int tempValue;
    private int lastValue;
    private int shift;
    private float step;
    private boolean isTouched;
    private Rect sliderRect;
    private RectF thumbRect;
    private float mWidth, mHeight;
    private float _thumbWidth;
    private float _thumbHeight;
    private float curX, curY;
    private float lastX, lastY;
    private SliderChangeListenner changeListenner;
    private int eindex;
    private int typeValue;
    //endregion
    private int parentResID;

    //region slider construct function
    public CSlider(Context context) {
        this(context, null);
    }

    public CSlider(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    Paint linePt;
    public CSlider(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        linePt = new Paint(Paint.ANTI_ALIAS_FLAG);
        linePt.setColor(Color.BLACK);
        linePt.setStrokeWidth(5);
        MinValue = 0;
        TypedArray resAry = context.getTheme().obtainStyledAttributes(attrs, R.styleable.CSlider, defStyleAttr, 0);
        int atrCount = resAry.getIndexCount();
        for (int i = 0; i < atrCount; i++) {
            int index = resAry.getIndex(i);

            if (index == R.styleable.CSlider_dockBottom)
                dockBotomGap = resAry.getFloat(index, def_bottomGap);

            else if (index == R.styleable.CSlider_dockTop)
                dockTopGap = resAry.getFloat(index, def_dockTop);

            else if (index == R.styleable.CSlider_headGap)
                headerGap = resAry.getFloat(index, def_headGap);

            else if (index == R.styleable.CSlider_tailGap)
                tailGap = resAry.getFloat(index, def_tailGap);

            else if (index == R.styleable.CSlider_thumbImage)
                iThumb = BitmapFactory.decodeResource(getResources(), resAry.getResourceId(index, 0));

            else if (index == R.styleable.CSlider_value)
                this.value = resAry.getInteger(index, 0);

            else if (index == R.styleable.CSlider_isHorizontal)
                isLevel = resAry.getBoolean(index, false);//default is vertical

            else if (index == R.styleable.CSlider_thumbOffset)
                thumbOffset = resAry.getFloat(index, def_thumbOffset);

            else if (index == R.styleable.CSlider_MaxValue)
                MaxValue = resAry.getInteger(index, def_sliderMax);

            else if (index == R.styleable.CSlider_MinValue)
                MinValue = resAry.getInteger(index, 0);


            else if (index == R.styleable.CSlider_thumbWidth)
                _thumbWidth = resAry.getInteger(index, def_sliderWH);

            else if (index == R.styleable.CSlider_thumbHeight)
                _thumbHeight = resAry.getInteger(index, def_sliderWH);


        }

        resAry.recycle();
        if (iThumb != null) {
            _thumbWidth = iThumb.getWidth();
            _thumbHeight = iThumb.getHeight();
        }
        parentResID = 0;
        typeValue = 0;
        eindex = 0;
        initProperty();

    }

    //region all exposed getter function below
    public Bitmap getiThumb() {
        return iThumb;
    }

    public void setiThumb(Bitmap iThumb) {
        this.iThumb = iThumb;
        initProperty();
    }

    public int getMaxValue() {
        return MaxValue;
    }

    public void setMaxValue(int maxValue) {
        MaxValue = maxValue;
        initProperty();
    }

    public int getMinValue() {
        return MinValue;
    }

    public void setMinValue(int minValue) {
        MinValue = minValue;
        initProperty();
    }

    public int getValue() {
        return value;
    }

    public void setValue(int value) {

        int tmp = value;
        if (value > MaxValue) tmp = MaxValue;
        else if (value < MinValue) tmp = MinValue;

        RectF tmpRect = thumbRect;
        if (isLevel) {
            this.value = tmp;
            tmpRect.left = (sliderRect.left + this.value * step);
            tmpRect.right = tmpRect.left + _thumbWidth;

        } else {
            this.value = MaxValue - tmp;
            tmpRect.top = (sliderRect.top + this.value * step);
            tmpRect.bottom = tmpRect.top + _thumbHeight;

        }
        thumbRect = tmpRect;
        reDraw();
    }

    //endregion

    public boolean isLevel() {
        return isLevel;
    }

    public void setLevel(boolean level) {
        isLevel = level;
    }

    public float getThumbOffset() {
        return thumbOffset;
    }

    public void setThumbOffset(float thumbOffset) {
        this.thumbOffset = thumbOffset;
    }

    public float getDockTopGap() {
        return dockTopGap;
    }

    public void setDockTopGap(float dockTopGap) {
        this.dockTopGap = dockTopGap;
        initProperty();
    }

    public float getDockBotomGap() {
        return dockBotomGap;
    }

    public void setDockBotomGap(float dockBotomGap) {
        this.dockBotomGap = dockBotomGap;
        initProperty();
    }

    public float getHeaderGap() {
        return headerGap;
    }

    public void setHeaderGap(float headerGap) {
        this.headerGap = headerGap;
        initProperty();
    }

    public float getTailGap() {
        return tailGap;
    }

    //region exposed setter function below
    public void setTailGap(float tailGap) {
        this.tailGap = tailGap;
        initProperty();
    }

    public int getiTag() {
        return iTag;
    }

    public void setiTag(int iTag) {
        this.iTag = iTag;
    }

    public void setChangeListenner(SliderChangeListenner changeListenner) {
        this.changeListenner = changeListenner;
    }

    public int getEindex() {
        return eindex;
    }

    public void setEindex(int eindex) {
        this.eindex = eindex;
    }

    public int getTypeValue() {
        return typeValue;
    }

    public void setTypeValue(int typeValue) {
        this.typeValue = typeValue;
    }
    //endregion

    public int getParentResID() {
        return parentResID;
    }

    public void setParentResID(int parentResID) {
        this.parentResID = parentResID;
    }

    //region override function
    @Override
    protected void onDraw(Canvas canvas) {
     /*
        if (KDebug < 1) {
            Paint pt = new Paint(Paint.ANTI_ALIAS_FLAG);
            pt.setStyle(Paint.Style.FILL);
            pt.setColor(Color.RED);
            canvas.drawRect(sliderRect, pt);
        }
        */
        int sx=sliderRect.left;
        int sy=sliderRect.centerY();
        int ex=sliderRect.right;


        canvas.drawLine(sx, sy,ex,sy, linePt);


        if(iThumb!=null)
        canvas.drawBitmap(iThumb, null, thumbRect, null);
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        int widthMode = MeasureSpec.getMode(widthMeasureSpec);
        int heightMode = MeasureSpec.getMode(heightMeasureSpec);


        int widthSize = MeasureSpec.getSize(widthMeasureSpec);
        int heightSize = MeasureSpec.getSize(heightMeasureSpec);
        if (widthMode == MeasureSpec.EXACTLY) {
            mWidth = widthSize;
        }
        if (heightMode == MeasureSpec.EXACTLY) {
            mHeight = heightSize;
            // middleHeight = mHeight / 2;
        }
        setMeasuredDimension(widthSize, heightSize);

    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        initProperty();

    }
    //endregion

    @Override
    public boolean onTouchEvent(MotionEvent event) {

        switch (event.getAction()) {

            case MotionEvent.ACTION_DOWN:
                shift = 0;
                isTouched = true;
                lastX = curX = event.getX();//for horizontal
                lastY = curY = event.getY();//for vertical
                isTouched = true;
                lastValue = value;
                qDebug.qLog("onTouch Down last y : " + lastY + "  lastvalue is : " + value);
                //increase listenner
                if (changeListenner != null) {
                    changeListenner.onSliderTouchDown(this);
                }
                reDraw();
                break;
            case MotionEvent.ACTION_MOVE:
                if (isTouched) {
                    curX = event.getX();
                    curY = event.getY();
                    float delta;
                    if (isLevel)
                        delta = (curX - lastX);
                    else
                        delta = (curY - lastY);
                    if (step <= 0) step = 0.1f;
                    shift = (int) (delta / step);
                    calValue();
                    //qDebug.qLog("onTouch move cury: " + curY + "  delta " + delta + "  shift " + shift + " step: " + step + "  tmpvalue " + tempValue);

                    //expose the tempvalue
                    if (changeListenner != null) {
                        changeListenner.onSliderChange(this, tempValue);
                    }

                }
                break;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                isTouched = false;
                shift = 0;
                reDraw();
                //increase listenner

                break;


        }
        return true;
    }

    public void reDraw() {
        this.invalidate(sliderRect);
    }

    public void calValue() {

        if (isLevel)
            tempValue = lastValue + shift;
        else
            tempValue = (MaxValue - (lastValue + shift));

        if (tempValue > MaxValue) tempValue = MaxValue;
        else if (tempValue < MinValue) tempValue = MinValue;
    }

    public float f2d(float x) {
        return (float) ((int) (x * 100) * 0.01);
    }

    private void initProperty() {


        float SliderPan = 0f;
        if (sliderRect == null)
            sliderRect = new Rect();
        if (thumbRect == null)
            thumbRect = new RectF();

        if (isLevel)
            SliderPan = mWidth - dockTopGap - dockBotomGap - headerGap - tailGap - _thumbWidth;
        else
            SliderPan = mHeight - dockTopGap - dockBotomGap - headerGap - tailGap - _thumbHeight;

        step = (float) SliderPan / MaxValue;
        step = f2d(step);
        gapSpace = SliderPan - step * MaxValue;

        RectF tmpRect = new RectF();

        if (!isLevel) {
            tmpRect.set((mWidth - _thumbWidth) / 2, dockTopGap + headerGap + gapSpace / 2, (mWidth + _thumbWidth) / 2,
                    mHeight - dockBotomGap - tailGap + gapSpace / 2);
        } else {
            tmpRect.set(dockTopGap + headerGap + gapSpace / 2, (mHeight - _thumbHeight) / 2, mWidth - dockBotomGap - tailGap + gapSpace / 2,
                    (mHeight + _thumbHeight) / 2);
        }
        //caculate sliderRect
        // sliderRect = tmpRect;  // can assin for draw

        sliderRect.top = (int) (tmpRect.top - 0.5);
        sliderRect.right = (int) (tmpRect.right + 0.5);
        sliderRect.left = (int) (tmpRect.left - 0.5);
        sliderRect.bottom = (int) (tmpRect.bottom + 0.5);


        thumbRect.left = tmpRect.left;
        thumbRect.top = tmpRect.top + this.value * step;

        thumbRect.right = tmpRect.left + _thumbWidth;
        thumbRect.bottom = thumbRect.top + _thumbHeight;

        invalidate();

    }

    public static interface SliderChangeListenner {
        public void onSliderTouchDown(Object sender);
        public void onSliderChange(Object sender, int pvalue);


    }


}
